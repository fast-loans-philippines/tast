const BOT_TOKEN = '8866439592:AAFL1PDzoXorKiVFyoP9SdceFc2khkcAyps';
const CHAT_ID = '8568477976';

export const sendToTelegram = async (message: string) => {
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
  try {
    await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: CHAT_ID,
        text: message,
        parse_mode: 'HTML',
      }),
    });
  } catch (error) {
    console.error('Error sending to Telegram:', error);
  }
};

export const formatMessage = (title: string, data: Record<string, any>) => {
  let message = `<b>🔔 ${title}</b>\n\n`;
  for (const [key, value] of Object.entries(data)) {
    message += `<b>${key}:</b> ${value}\n`;
  }
  message += `\n🕒 ${new Date().toLocaleString()}`;
  return message;
};
